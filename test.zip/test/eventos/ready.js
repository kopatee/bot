//Esta función se activara cuando el evento haya iniciado:
module.exports = (client) => {
  
    client.user.setPresence( 
      {
        status: "busy", 
        game: { 
          name: 'kopate testing', 
          url: null, // Establece el enlace del juego si el tipo es "STREAMING".
          type: "PLAYING"
        }
      }
    );
   
    
  }