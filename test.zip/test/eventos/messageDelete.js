module.exports = (client, message) => {
    let canal = client.channels.cache.get('666582480668852238'); 
    canal.send(`**${message.author.username}** elimino un mensaje con el contenido: ${message}`);
  
  }