module.exports = (client, member) => {

    member.guild.channels.cache.get("ID-CANAL").send(`Bienvenido ${member.user.username}!!`)
   
   }
   