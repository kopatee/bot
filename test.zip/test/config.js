let config = {
    token: "NzUzMDY4MjY5NDkzMDI2OTM2.X1gzeg.Xjk8wKgPi1b7kvrq5HF1lGvcaG4", // Reemplaze esto con el token de tu de bot.
    prefix: "g!", // El prefix de su bot para indentificar sus comandos.
  
  }
  
  // Aqui exportamos el objeto config:
  module.exports = config;