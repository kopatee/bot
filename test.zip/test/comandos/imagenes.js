const { MessageAttachment } = require("discord.js")
const array = ['ejemplo1.jpg', 'ejemplo2.png']

module.exports = (client, message, args) => { 
    const r = array[Math.round(Math.random() * array.length)]
    const route = require("../imagenes/"+r)
    
    message.channel.send(new MessageAttachment(route, 'enviado.jpg'))

}