//Esta función recibe el parametro client, message, y args para ser usados:
module.exports = (client, message, args) => { 
    message.channel.send("Pong!"); 
  
  }
  